"""
A module to read Raven Aerostar flight telemetry data from the Future Engineers TechRise flight simulator.
Data is read over UART (RX pin on most CircuitPython boards).
Defines a Simulator class with properties to determine when a new packet is available.
Helper property functions are included to convert from telemetry format to usable values.

Raven Aerostar data format:
    * Transmitted via serial connection: 115200 baud, 8N1
    * 79-byte data packet, big endian
    * 10Hz telemetry packets

Data fields:
    Separator (2):
        | uint16    *Sync Word*, 0x55 0xAA
    Header (10):
        | uint16    *CRC Checksum*, Not used by simulator
        | uint32[2] *Time*, Linux Epoch in seconds and microseconds (UTC currentmillis/1000)
    Payload (67):
        | int32[2]  *Latitude* and *Longitude*, in degrees
        | int32     *Altitude*, in meters
        | int32[3]  *Roll*, *Pitch*, *Yaw*, in degrees
        | int32[3]  *Acceleration* *X*, *Y*, *Z*, in meters/second^2
        | int32     *Pressure*, in kPa
        | int32     *Course*, relative to true north, in degrees
        | int32     *Speed*, in knots
        | int32[3]  *Velocity* *North*, *East*, *Down*, in meters/second
        | int32     *Declination*, magnetic declination for this position, in degrees
        | uint16    Number of *GPS Satellites Visible*
        | uint8     *GPS Fix Type*, current GPS Fix

Payload values:
    | See property helper functions below for conversion from fixed-point to floating-point value.

GPS Fix Type:
    | GPS_NO_FIX = 0
    | GPS_DEAD_RECKONING = 1
    | GPS_2D = 2
    | GPS_3D = 3
    | GPS_GNSS_DEAD_RECK = 4
    | GPS_TIME_ONLY = 5
"""

# Written by Mark DeLoura and Arnie Martin for Future Engineers
# Last Updated: 1/12/2022

from time import monotonic
from board import RX as BOARD_RX, TX as BOARD_TX
from busio import UART
from digitalio import DigitalInOut, Direction

# Internal constants
_BUFFER_SIZE = const(1024)
_BUFFER_SIZE_MASK = const(0x3ff)
_RECEIVER_BUFFER_SIZE = const(512)
_PACKET_SIZE = const(79)
_DEFAULT_BAUD_RATE = const(115200)
_UART_TIMEOUT = 0.1

_SYNCBYTE1 = const(0x55)
_SYNCBYTE2 = const(0xAA)

_MODE_FINDING_SYNCBYTE1 = const(1)
_MODE_FINDING_SYNCBYTE2 = const(2)
_MODE_FINDING_PAYLOAD   = const(3)

class Simulator:
    """Simulator class - Conducts Raven Aerostar flight telemetry processing

       | :py:meth:`Simulator.update` - Processes incoming flight telemetry data 
       | :py:attr:`Simulator.new_data` - True if new data has been received
       | :py:attr:`Simulator.streaming` - True if data is streaming
       | :py:attr:`Simulator.pbf` - Value of Pull-Before-Flight Header, True = removed
       | :py:attr:`Simulator.go` - Value of the GO LED, True = lit
       | :py:attr:`Simulator.data` - Value of the new full data packet as a bytearray

    Use .data to acquire all telemetry fields of the current packet. 
    To acquire individual data fields from the current packet, use the helper properties detailed below.

    """

    def __init__(self, pbf_pin=None, go_pin=None):
        """Initializes the simulator
        
        :param pbf_pin is a board.XX pin connected to the PBF pin on PIB J5
        :param go_pin is a board.XX pin connected to the GO pin on PIB J5
        """

        # declare private variables
        self._new_data = False
        self._data = None
        self._streaming = False
        self._stream_timeout = 0
        self._event = None
        self._uart_pre = None
        self._pbf_pin = pbf_pin
        self._go_pin = go_pin

        self._buffer = bytearray(_BUFFER_SIZE)
        self._mv = memoryview(self._buffer)

        self._curr_packet_buffer = bytearray(_PACKET_SIZE)
        self._curr_packet_buffer_mv = memoryview(self._curr_packet_buffer)

        self._return_buffer = bytearray(_PACKET_SIZE)

        self._mode = _MODE_FINDING_SYNCBYTE1
        self._save_start = 0
        self._save_end = 0
        self._packet_start = 0
        self._packet_end = 0
        self._packet_bytes_found = 0

        # set the onboard UART pin
        self._uart = UART(BOARD_TX, BOARD_RX,
                          baudrate=_DEFAULT_BAUD_RATE, timeout=_UART_TIMEOUT,
                          receiver_buffer_size=_RECEIVER_BUFFER_SIZE)

        # setup the pbf_pin and go_pin
        if self._pbf_pin is not None:
            self._pbf = DigitalInOut(self._pbf_pin)
            self._pbf.direction = Direction.INPUT
            print("Pull before flight active on", self._pbf_pin)
        else:
            print("Pull before flight header disabled")
        if self._go_pin is not None:
            self._go = DigitalInOut(self._go_pin)
            self._go.direction = Direction.OUTPUT
            print("GO pin active on", self._go_pin)
        else:
            print("GO pin disabled")

    def update(self):
        """Processes incoming flight telemetry data"""

        bytes_waiting = self._uart.in_waiting
        if bytes_waiting > 0:
            first_packets = 0
            is_wrapped_load = False
            is_wrapped_packet = False

            # Grab self vars to improve performance
            mv = self._mv
            curr_mv = self._curr_packet_buffer_mv
            uart = self._uart
            mode = self._mode
            save_start = self._save_start
            save_end = self._save_end
            packet_start = self._packet_start
            packet_end = self._packet_end
            packet_bytes_found = self._packet_bytes_found

            # Copy waiting bytes to ring buffer, from saveStart to saveEnd
            #   Wrap ring buffer if load goes past end of buffer
            save_end = save_start + bytes_waiting
            is_wrapped_load = (save_end >= _BUFFER_SIZE)
            if is_wrapped_load:
                first_packets = _BUFFER_SIZE - save_start
                mv[save_start:_BUFFER_SIZE] = uart.read(first_packets)
                mv[0:save_end & _BUFFER_SIZE_MASK] = \
                    uart.read(bytes_waiting - first_packets)
            else:
                mv[save_start:save_end] = uart.read(bytes_waiting)

            # Process new bytes one by one
            #   Advance through modes based on data:
            #     MODE_FINDING_SYNCBYTE1 - looking for 0x55 packet start
            #     MODE_FINDING_SYNCBYTE2 - looking for 0xAA, second packet byte
            #     MODE_FINDING_PAYLOAD   - looking for rest of 45 byte packet
            #   When full packet found, copy to currMV. Deal with wrap if necessary.
            save_range = range(save_start, save_end)
            for index in save_range:
                wrapped_index = index & _BUFFER_SIZE_MASK

                if mode == _MODE_FINDING_SYNCBYTE1:
                    if mv[wrapped_index] == _SYNCBYTE1:
                        mode = _MODE_FINDING_SYNCBYTE2
                        packet_start = wrapped_index

                elif mode == _MODE_FINDING_SYNCBYTE2:
                    if mv[wrapped_index] == _SYNCBYTE2:
                        mode = _MODE_FINDING_PAYLOAD
                        packet_bytes_found = 2
                    else: # if SYNCBYTE2 is not immediately after SYNCBYTE1, start over
                        mode = _MODE_FINDING_SYNCBYTE1

                elif mode == _MODE_FINDING_PAYLOAD:
                    packet_bytes_found = packet_bytes_found + 1
                    if packet_bytes_found == _PACKET_SIZE:     # Full packet found
                        packet_end = wrapped_index
                        is_wrapped_packet = ((packet_end+1) -
                            _PACKET_SIZE < 0)
                        if is_wrapped_packet:
                            first_packets = _BUFFER_SIZE - packet_start
                            curr_mv[0:first_packets] = \
                                mv[packet_start:_BUFFER_SIZE]
                            curr_mv[first_packets:_PACKET_SIZE] = \
                                mv[0:packet_end+1]
                        else:
                            curr_mv[0:_PACKET_SIZE] = \
                                mv[packet_start:packet_end+1]

                        self._new_data = True
                        self._stream_timeout = monotonic() + 1.5
                        mode = _MODE_FINDING_SYNCBYTE1
                else:
                    raise Exception('UART data state machine error')

            save_start = save_end & _BUFFER_SIZE_MASK

            # Save state back to self
            self._mode = mode
            self._save_start = save_start
            self._save_end = save_end
            self._packet_start = packet_start
            self._packet_end = packet_end
            self._packet_bytes_found = packet_bytes_found

        # if the pbf and go headers are active, read the former and set the latter
        if (self._pbf_pin is not None) and (self._go_pin is not None):
            # check if the pbf header is inserted
            if self._pbf.value:
                # it is not, so turn on the go led
                self._go.value = True
            else:
                # it must be so turn off the go led
                self._go.value = False

    @property
    def new_data(self) -> bool:
        """Returns True if new data has been received"""

        if self._new_data:
            return True
        else:
            return False

    @property
    def streaming(self) -> bool:
        """Returns True if data is streaming, and recieve timeout has not been exceeded"""

        if monotonic() <= self._stream_timeout:
            return True
        else:
            return False

    @property
    def pbf(self) -> bool:
        """Returns value of the Pull-Before-Flight Header, True if Header removed"""

        if self._pbf_pin is not None:
            return self._pbf.value
        else:
            return None

    @property
    def go(self) -> bool:
        """Returns value of the GO LED"""

        if self._go_pin is not None:
            return self._go.value
        else:
            return None

    @go.setter
    def go(self, val:bool):
        """Sets GO pin
        
        :param val: Value for GO LED
        :type val: bool
        """

        if self._go_pin is not None:
            if isinstance(val, bool):
                self._go.value = val
            else:
                raise Exception(".go value must be True/False")
        else:
            raise Exception("Go pin must be declared in TRsim initializer")

    @property
    def data(self) -> bytearray:
        """Returns the new full data packet as a bytearray"""

        if self._new_data:
            self._new_data = False
            self._return_buffer[:] = self._curr_packet_buffer
            return self._return_buffer
        else:
            return None

    @property
    def time_secs(self) -> int:
        """Returns current Linux Epoch (UTC) time, seconds portion"""

        if self.streaming:
            return ((self._curr_packet_buffer_mv[4]<<24)|\
                (self._curr_packet_buffer_mv[5]<<16)|\
                (self._curr_packet_buffer_mv[6]<<8)|\
                (self._curr_packet_buffer_mv[7]))
        else:
            return None

    @property
    def time_usecs(self) -> int:
        """Returns current Linux Epoch (UTC) time, microseconds portion"""

        if self.streaming:
            return ((self._curr_packet_buffer_mv[8]<<24)|\
                (self._curr_packet_buffer_mv[9]<<16)|\
                (self._curr_packet_buffer_mv[10]<<8)|\
                (self._curr_packet_buffer_mv[11]))
        else:
            return None

    @property
    def latitude(self) -> float:
        """Returns latitude, in degrees"""

        if self.streaming:
            if self._curr_packet_buffer_mv[12]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[12]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[13]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[14]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[15]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[12]<<24) | \
                            (self._curr_packet_buffer_mv[13]<<16) | \
                            (self._curr_packet_buffer_mv[14]<<8) | \
                            (self._curr_packet_buffer_mv[15])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def longitude(self) -> float:
        """Returns longitude, in degrees"""

        if self.streaming:
            if self._curr_packet_buffer_mv[16]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[16]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[17]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[18]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[19]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[16]<<24) | \
                            (self._curr_packet_buffer_mv[17]<<16) | \
                            (self._curr_packet_buffer_mv[18]<<8) | \
                            (self._curr_packet_buffer_mv[19])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def altitude(self) -> float:
        """Returns altitude, in meters"""

        if self.streaming:
            if self._curr_packet_buffer_mv[20]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[20]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[21]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[22]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[23]&0xff)
                retval = -(intval+1) / (1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[20]<<24) | \
                            (self._curr_packet_buffer_mv[21]<<16) | \
                            (self._curr_packet_buffer_mv[22]<<8) | \
                            (self._curr_packet_buffer_mv[23])
                retval = intval / (1024.0)
            return retval
        else:
            return None

    @property
    def roll(self) -> float:
        """Returns roll, in degrees"""

        if self.streaming:
            if self._curr_packet_buffer_mv[24]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[24]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[25]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[26]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[27]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[24]<<24) | \
                            (self._curr_packet_buffer_mv[25]<<16) | \
                            (self._curr_packet_buffer_mv[26]<<8) | \
                            (self._curr_packet_buffer_mv[27])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def pitch(self) -> float:
        """Returns pitch, in degrees"""

        if self.streaming:
            if self._curr_packet_buffer_mv[28]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[28]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[29]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[30]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[31]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[28]<<24) | \
                            (self._curr_packet_buffer_mv[29]<<16) | \
                            (self._curr_packet_buffer_mv[30]<<8) | \
                            (self._curr_packet_buffer_mv[31])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def yaw(self) -> float:
        """Returns yaw, in degrees"""

        if self.streaming:
            if self._curr_packet_buffer_mv[32]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[32]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[33]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[34]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[35]&0xff)
                retval = -(intval+1) / (1024.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[32]<<24) | \
                            (self._curr_packet_buffer_mv[33]<<16) | \
                            (self._curr_packet_buffer_mv[34]<<8) | \
                            (self._curr_packet_buffer_mv[35])
                retval = intval / (1024.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def acceleration_x(self) -> float:
        """Returns acceleration in X direction, in meters/second^2"""

        if self.streaming:
            if self._curr_packet_buffer_mv[36]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[36]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[37]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[38]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[39]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[36]<<24) | \
                            (self._curr_packet_buffer_mv[37]<<16) | \
                            (self._curr_packet_buffer_mv[38]<<8) | \
                            (self._curr_packet_buffer_mv[39])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def acceleration_y(self) -> float:
        """Returns acceleration in Y direction, in meters/second^2"""

        if self.streaming:
            if self._curr_packet_buffer_mv[40]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[40]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[41]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[42]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[43]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[40]<<24) | \
                            (self._curr_packet_buffer_mv[41]<<16) | \
                            (self._curr_packet_buffer_mv[42]<<8) | \
                            (self._curr_packet_buffer_mv[43])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def acceleration_z(self) -> float:
        """Returns acceleration in Z direction, in meters/second^2"""

        if self.streaming:
            if self._curr_packet_buffer_mv[44]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[44]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[45]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[46]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[47]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[44]<<24) | \
                            (self._curr_packet_buffer_mv[45]<<16) | \
                            (self._curr_packet_buffer_mv[46]<<8) | \
                            (self._curr_packet_buffer_mv[47])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def pressure(self) -> float:
        """Returns atmospheric pressure, in kPa"""

        if self.streaming:
            if self._curr_packet_buffer_mv[48]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[48]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[49]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[50]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[51]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[48]<<24) | \
                            (self._curr_packet_buffer_mv[49]<<16) | \
                            (self._curr_packet_buffer_mv[50]<<8) | \
                            (self._curr_packet_buffer_mv[51])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def course(self) -> float:
        """Returns course, relative to true north, in degrees"""

        if self.streaming:
            if self._curr_packet_buffer_mv[52]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[52]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[53]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[54]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[55]&0xff)
                retval = -(intval+1) / (1024.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[52]<<24) | \
                            (self._curr_packet_buffer_mv[53]<<16) | \
                            (self._curr_packet_buffer_mv[54]<<8) | \
                            (self._curr_packet_buffer_mv[55])
                retval = intval / (1024.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def speed(self) -> float:
        """Returns speed, in knots"""

        if self.streaming:
            if self._curr_packet_buffer_mv[56]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[56]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[57]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[58]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[59]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[56]<<24) | \
                            (self._curr_packet_buffer_mv[57]<<16) | \
                            (self._curr_packet_buffer_mv[58]<<8) | \
                            (self._curr_packet_buffer_mv[59])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def velocity_north(self) -> float:
        """Returns northward velocity, in meters/second"""

        if self.streaming:
            if self._curr_packet_buffer_mv[60]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[60]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[61]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[62]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[63]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[60]<<24) | \
                            (self._curr_packet_buffer_mv[61]<<16) | \
                            (self._curr_packet_buffer_mv[62]<<8) | \
                            (self._curr_packet_buffer_mv[63])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def velocity_east(self) -> float:
        """Returns eastward velocity, in meters/second"""

        if self.streaming:
            if self._curr_packet_buffer_mv[64]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[64]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[65]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[66]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[67]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[64]<<24) | \
                            (self._curr_packet_buffer_mv[65]<<16) | \
                            (self._curr_packet_buffer_mv[66]<<8) | \
                            (self._curr_packet_buffer_mv[67])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def velocity_down(self) -> float:
        """Returns downward velocity, in meters/second"""

        if self.streaming:
            if self._curr_packet_buffer_mv[68]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[68]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[69]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[70]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[71]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[68]<<24) | \
                            (self._curr_packet_buffer_mv[69]<<16) | \
                            (self._curr_packet_buffer_mv[70]<<8) | \
                            (self._curr_packet_buffer_mv[71])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def declination(self) -> float:
        """Returns magnetic declination for this position, in degrees"""

        if self.streaming:
            if self._curr_packet_buffer_mv[72]&0x80 == 0x80:
                intval = ((~self._curr_packet_buffer_mv[72]&0xff)<<24) | \
                            ((~self._curr_packet_buffer_mv[73]&0xff)<<16) | \
                            ((~self._curr_packet_buffer_mv[74]&0xff)<<8) | \
                            (~self._curr_packet_buffer_mv[75]&0xff)
                retval = -(intval+1) / (8192.0 * 1024.0)
            else:
                intval = (self._curr_packet_buffer_mv[72]<<24) | \
                            (self._curr_packet_buffer_mv[73]<<16) | \
                            (self._curr_packet_buffer_mv[74]<<8) | \
                            (self._curr_packet_buffer_mv[75])
                retval = intval / (8192.0 * 1024.0)
            return retval
        else:
            return None

    @property
    def num_sats(self) -> int:
        """Returns number of GPS Satellites visible"""

        if self.streaming:
            return (self._curr_packet_buffer_mv[76]<<8) | self._curr_packet_buffer_mv[77]
        else:
            return None

    @property
    def gps_fix(self) -> int:
        """Returns GPS Fix Type"""

        if self.streaming:
            return self._curr_packet_buffer_mv[78]
        else:
            return None
